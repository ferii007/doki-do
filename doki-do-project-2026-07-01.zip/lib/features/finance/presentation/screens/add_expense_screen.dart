import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../app/router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/formatters/currency_input_formatter.dart';
import '../../../../core/localization/app_localizations.dart';
import '../../../../core/widgets/app_toast.dart';
import '../../../../core/widgets/error_view.dart';
import '../../../../core/widgets/loading_view.dart';
import '../providers/current_budget_provider.dart';
import '../providers/selected_period_provider.dart';
import '../providers/transaction_action_provider.dart';
import '../widgets/transaction_form/amount_input.dart';
import '../widgets/transaction_form/budget_period_picker.dart';
import '../widgets/transaction_form/category_picker.dart';
import '../widgets/transaction_form/transaction_date_picker.dart';
import '../widgets/transaction_form/transaction_note_field.dart';

class AddExpenseScreen extends ConsumerStatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  ConsumerState<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends ConsumerState<AddExpenseScreen> {
  final _amountController = TextEditingController();
  final _titleController = TextEditingController();
  String? _periodId;
  String? _categoryId;
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    _amountController.dispose();
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final periodsAsync = ref.watch(budgetPeriodsProvider);
    final selectedDashboardPeriodId = ref.watch(selectedPeriodIdProvider);
    final isSaving = ref.watch(transactionActionProvider);
    final activePeriodId = _periodId ?? selectedDashboardPeriodId;
    final budgetAsync = activePeriodId == null
        ? ref.watch(currentBudgetProvider)
        : ref.watch(budgetByPeriodProvider(activePeriodId));

    return Scaffold(
      appBar: AppBar(title: Text(context.tr('record_expense'))),
      body: periodsAsync.when(
        loading: () => const LoadingView(),
        error: (error, _) => ErrorView(error: error),
        data: (periods) {
          if (periods.isEmpty) {
            return const _CreatePeriodPrompt();
          }

          _periodId ??=
              selectedDashboardPeriodId ??
              (periods.isEmpty ? null : periods.first.id);

          return budgetAsync.when(
            loading: () => const LoadingView(),
            error: (error, _) => ErrorView(error: error),
            data: (snapshot) {
              if (snapshot == null) {
                return const _CreatePeriodPrompt();
              }

              _date = _clampDate(
                _date,
                snapshot.period.startDate,
                snapshot.period.endDate,
              );
              final validCategory = snapshot.categories.any(
                (category) => category.id == _categoryId,
              );
              if (!validCategory) {
                _categoryId = snapshot.categories.isEmpty
                    ? null
                    : snapshot.categories.first.id;
              }

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  BudgetPeriodPicker(
                    periods: periods,
                    selectedPeriodId: _periodId,
                    onChanged: (value) {
                      final period = periods.firstWhere(
                        (item) => item.id == value,
                        orElse: () => periods.first,
                      );
                      setState(() {
                        _periodId = value;
                        _categoryId = null;
                        _date = _clampDate(
                          _date,
                          period.startDate,
                          period.endDate,
                        );
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  CategoryPicker(
                    categories: snapshot.categories,
                    selectedCategoryId: _categoryId,
                    onChanged: (value) => setState(() => _categoryId = value),
                  ),
                  const SizedBox(height: 12),
                  AmountInput(controller: _amountController),
                  const SizedBox(height: 12),
                  TransactionNoteField(
                    controller: _titleController,
                    label: context.tr('what_was_it_used_for'),
                  ),
                  const SizedBox(height: 12),
                  TransactionDatePicker(
                    date: _date,
                    firstDate: snapshot.period.startDate,
                    lastDate: snapshot.period.endDate,
                    onChanged: (value) => setState(() => _date = value),
                  ),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: isSaving ? null : _submit,
                    child: Text(
                      context.tr(isSaving ? 'saving' : 'save_expense'),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _submit() async {
    final amount = CurrencyInputFormatter.parse(_amountController.text);
    final title = _titleController.text.trim();
    final periodId = _periodId;
    final categoryId = _categoryId;

    if (periodId == null) {
      AppToast.show(
        context,
        context.tr('choose_a_period_for_this_expense_first'),
      );
      return;
    }

    if (categoryId == null) {
      AppToast.show(context, context.tr('choose_the_budget_category_first'));
      return;
    }

    if (amount <= 0) {
      AppToast.show(context, context.tr('enter_the_expense_amount_first'));
      return;
    }

    if (title.isEmpty) {
      AppToast.show(
        context,
        context.tr('write_what_the_money_was_used_for_first'),
      );
      return;
    }

    await ref
        .read(transactionActionProvider.notifier)
        .addExpense(
          periodId: periodId,
          categoryId: categoryId,
          amount: amount,
          title: title,
          date: _date,
        );

    if (mounted) {
      AppToast.show(context, context.tr('expense_recorded_successfully'));
      Navigator.pop(context);
    }
  }

  DateTime _clampDate(DateTime value, DateTime min, DateTime max) {
    if (value.isBefore(min)) return min;
    if (value.isAfter(max)) return max;
    return value;
  }
}

class _CreatePeriodPrompt extends StatelessWidget {
  const _CreatePeriodPrompt();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.date_range_rounded, color: AppColors.primary, size: 42),
            const SizedBox(height: 12),
            Text(
              context.tr('create_a_financial_period_first_2'),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              context.tr(
                'expenses_need_to_be_placed_in_a_period_and_budget_category',
              ),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () =>
                  Navigator.pushNamed(context, AppRouter.addPeriod),
              icon: const Icon(Icons.add_rounded),
              label: Text(context.tr('create_period')),
            ),
          ],
        ),
      ),
    );
  }
}
