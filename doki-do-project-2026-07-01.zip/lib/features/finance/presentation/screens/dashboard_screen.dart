import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../app/router.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../core/formatters/date_formatter.dart';
import '../../../../core/localization/app_localizations.dart';
import '../../../../core/widgets/app_toast.dart';
import '../../../../core/widgets/delete_confirmation_dialog.dart';
import '../../../../core/widgets/error_view.dart';
import '../../../../core/widgets/loading_view.dart';
import '../../domain/entities/budget_period.dart';
import '../../domain/entities/budget_snapshot.dart';
import '../../domain/entities/category_budget.dart';
import '../providers/current_budget_provider.dart';
import '../providers/selected_period_provider.dart';
import '../providers/transaction_action_provider.dart';
import '../widgets/dashboard/budget_category_grid.dart';
import '../widgets/dashboard/category_adjustment_sheet.dart';
import '../widgets/dashboard/category_edit_sheet.dart';
import '../widgets/dashboard/period_selector_sheet.dart';
import '../widgets/dashboard/period_statistics_chart.dart';
import '../widgets/dashboard/period_summary_card.dart';
import '../widgets/dashboard/profile_tab_body.dart';
import '../widgets/dashboard/quick_action_sheet.dart';
import '../widgets/dashboard/settings_tab_body.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final budgetAsync = ref.watch(currentBudgetProvider);
    final periodsAsync = ref.watch(budgetPeriodsProvider);
    final selectedPeriodId = ref.watch(selectedPeriodIdProvider);
    final isSaving = ref.watch(transactionActionProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('DokiDo'),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: budgetAsync.when(
        loading: () => const LoadingView(),
        error: (error, _) => ErrorView(error: error),
        data: (snapshot) {
          if (snapshot == null) {
            return RefreshIndicator(
              onRefresh: () => ref.refresh(currentBudgetProvider.future),
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  if (_selectedIndex == 0)
                    _EmptyPeriodTab(
                      title: context.tr('no_financial_period_yet'),
                      message: context.tr(
                        'create_your_first_period_so_income_expenses_and_budget_categories_can_be',
                      ),
                      onActionTap: () =>
                          Navigator.pushNamed(context, AppRouter.addPeriod),
                    )
                  else if (_selectedIndex == 1)
                    _EmptyPeriodTab(
                      title: context.tr('budget_cannot_be_created_yet'),
                      message: context.tr(
                        'add_a_financial_period_first_then_organize_budget_categories_for_that_pe',
                      ),
                      onActionTap: () =>
                          Navigator.pushNamed(context, AppRouter.addPeriod),
                    )
                  else if (_selectedIndex == 2)
                    const ProfileTabBody(currentSnapshot: null)
                  else
                    const SettingsTabBody(),
                ],
              ),
            );
          }

          final showPeriodHero = _selectedIndex <= 1;

          return RefreshIndicator(
            onRefresh: () => ref.refresh(currentBudgetProvider.future),
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                if (showPeriodHero)
                  PeriodSummaryCard(
                    period: snapshot.period,
                    totalExpense: snapshot.totalExpense,
                    onPeriodTap: () {
                      periodsAsync.whenData((periods) {
                        _showPeriodSelector(
                          context: context,
                          periods: periods,
                          selectedPeriodId:
                              selectedPeriodId ?? snapshot.period.id,
                          isAdding: isSaving,
                        );
                      });
                    },
                    onIncomeTap: () {
                      Navigator.pushNamed(
                        context,
                        AppRouter.incomeDetail,
                        arguments: snapshot.period.id,
                      );
                    },
                    onExpenseTap: () {
                      Navigator.pushNamed(
                        context,
                        AppRouter.expenseDetail,
                        arguments: snapshot.period.id,
                      );
                    },
                  ),
                if (_selectedIndex == 0) ...[
                  _DashboardTabBody(currentSnapshot: snapshot),
                ] else if (_selectedIndex == 1) ...[
                  _BudgetTabBody(
                    snapshot: snapshot,
                    onAddTap: () {
                      _showQuickActionSheet();
                    },
                    onCategoryTap: (category) {
                      Navigator.pushNamed(
                        context,
                        AppRouter.categoryDetail,
                        arguments: category.id,
                      );
                    },
                    onCategoryEdit: _showCategoryEditSheet,
                    onCategoryIncrease: (category) =>
                        _showCategoryAdjustmentSheet(
                          category,
                          CategoryAdjustmentAction.increase,
                        ),
                    onCategoryDecrease: (category) =>
                        _showCategoryAdjustmentSheet(
                          category,
                          CategoryAdjustmentAction.decrease,
                        ),
                    onCategorySetAmount: (category) =>
                        _showCategoryAdjustmentSheet(
                          category,
                          CategoryAdjustmentAction.setAmount,
                        ),
                    onCategoryDelete: _deleteCategory,
                    onCategoryDeleteBlocked: (_) {
                      AppToast.show(
                        context,
                        context.tr(
                          'this_budget_category_cannot_be_deleted_because_it_already_has_history',
                        ),
                      );
                    },
                  ),
                ] else ...[
                  if (_selectedIndex == 2)
                    ProfileTabBody(currentSnapshot: snapshot)
                  else
                    const SettingsTabBody(),
                ],
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: _DashboardFooter(
        selectedIndex: _selectedIndex,
        onChanged: (index) {
          setState(() => _selectedIndex = index);
        },
      ),
    );
  }

  void _showQuickActionSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => const QuickActionSheet(),
    );
  }

  Future<void> _showCategoryEditSheet(CategoryBudget category) async {
    final snapshot = await ref.read(currentBudgetProvider.future);
    if (!mounted) return;
    if (snapshot == null) {
      AppToast.show(context, context.tr('create_a_financial_period_first'));
      return;
    }

    final result = await showModalBottomSheet<CategoryEditResult>(
      context: context,
      isScrollControlled: true,
      builder: (_) => CategoryEditSheet(category: category),
    );
    if (result == null || !mounted) return;

    await ref
        .read(transactionActionProvider.notifier)
        .updateCategory(
          periodId: snapshot.period.id,
          categoryId: category.id,
          name: result.name,
        );
    if (!mounted) return;
    AppToast.show(context, context.tr('budget_category_updated_successfully'));
  }

  Future<void> _showCategoryAdjustmentSheet(
    CategoryBudget category,
    CategoryAdjustmentAction action,
  ) async {
    final snapshot = await ref.read(currentBudgetProvider.future);
    if (!mounted) return;
    if (snapshot == null) {
      AppToast.show(context, context.tr('create_a_financial_period_first'));
      return;
    }

    final result = await showModalBottomSheet<CategoryAdjustmentResult>(
      context: context,
      isScrollControlled: true,
      builder: (_) => CategoryAdjustmentSheet(
        category: category,
        categories: snapshot.categories,
        action: action,
      ),
    );
    if (result == null || !mounted) return;

    try {
      await ref
          .read(transactionActionProvider.notifier)
          .adjustCategoryBudget(
            periodId: snapshot.period.id,
            categoryId: category.id,
            action: result.action,
            amount: result.amount,
            reason: result.reason,
            date: DateTime.now(),
            relatedCategoryId: result.relatedCategoryId,
          );
      if (!mounted) return;
      AppToast.show(context, context.tr('budget_adjusted_successfully'));
    } on StateError catch (error) {
      if (!mounted) return;
      AppToast.show(context, error.message);
    }
  }

  Future<void> _deleteCategory(CategoryBudget category) async {
    final snapshot = await ref.read(currentBudgetProvider.future);
    if (!mounted) return;
    if (snapshot == null) {
      AppToast.show(context, context.tr('create_a_financial_period_first'));
      return;
    }

    final confirmed = await showDeleteConfirmationDialog(
      context,
      title: context.tr('delete_budget_category'),
      message: context.l10n.budgetDeleteMessage(category.name),
    );
    if (!confirmed || !mounted) return;

    await ref
        .read(transactionActionProvider.notifier)
        .deleteCategory(periodId: snapshot.period.id, categoryId: category.id);
    if (!mounted) return;
    AppToast.show(context, context.tr('budget_category_deleted_successfully'));
  }

  Future<void> _showPeriodSelector({
    required BuildContext context,
    required List<BudgetPeriod> periods,
    required String selectedPeriodId,
    required bool isAdding,
  }) async {
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => PeriodSelectorSheet(
        periods: periods,
        selectedPeriodId: selectedPeriodId,
        isAdding: isAdding,
        onSelect: (periodId) {
          ref.read(selectedPeriodIdProvider.notifier).select(periodId);
          Navigator.pop(context);
        },
        onDeletePeriod: (period) async {
          final confirmed = await showDeleteConfirmationDialog(
            context,
            title: context.tr('delete_financial_period'),
            message: context.l10n.periodDeleteMessage(
              DateFormatter.periodFull(period.startDate, period.endDate),
            ),
          );
          if (!confirmed) return;

          try {
            await ref
                .read(transactionActionProvider.notifier)
                .deleteBudgetPeriod(period.id);
            if (!context.mounted) return;
            Navigator.pop(context);
            AppToast.show(
              context,
              context.tr('financial_period_deleted_successfully'),
            );
          } catch (_) {
            if (!context.mounted) return;
            AppToast.show(
              context,
              context.tr(
                'this_period_cannot_be_deleted_because_it_already_has_income_or_expense_r',
              ),
            );
          }
        },
        onAddPeriod: () async {
          Navigator.pop(context);
          await Navigator.pushNamed(context, AppRouter.addPeriod);
        },
      ),
    );
  }
}

class _EmptyPeriodTab extends StatelessWidget {
  final String title;
  final String message;
  final VoidCallback onActionTap;

  const _EmptyPeriodTab({
    required this.title,
    required this.message,
    required this.onActionTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: AppColors.warmGradient,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withValues(alpha: 0.72)),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withValues(alpha: 0.12),
              blurRadius: 24,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(
                Icons.date_range_rounded,
                color: Colors.white,
                size: 30,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w700,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: onActionTap,
              icon: const Icon(Icons.add_rounded),
              label: Text(context.tr('create_financial_period')),
            ),
          ],
        ),
      ),
    );
  }
}

class _DashboardFooter extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  const _DashboardFooter({
    required this.selectedIndex,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(
            top: BorderSide(color: AppColors.border.withValues(alpha: 0.8)),
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.overlay.withValues(alpha: 0.04),
              blurRadius: 14,
              offset: const Offset(0, -6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _FooterIconButton(
              selected: selectedIndex == 0,
              icon: Icons.dashboard_outlined,
              selectedIcon: Icons.dashboard,
              onTap: () => onChanged(0),
            ),
            _FooterIconButton(
              selected: selectedIndex == 1,
              icon: Icons.account_balance_wallet_outlined,
              selectedIcon: Icons.account_balance_wallet,
              onTap: () => onChanged(1),
            ),
            _FooterIconButton(
              selected: selectedIndex == 2,
              icon: Icons.person_outline_rounded,
              selectedIcon: Icons.person_rounded,
              onTap: () => onChanged(2),
            ),
            _FooterIconButton(
              selected: selectedIndex == 3,
              icon: Icons.settings_outlined,
              selectedIcon: Icons.settings_rounded,
              onTap: () => onChanged(3),
            ),
          ],
        ),
      ),
    );
  }
}

class _FooterIconButton extends StatelessWidget {
  final bool selected;
  final IconData icon;
  final IconData selectedIcon;
  final VoidCallback onTap;

  const _FooterIconButton({
    required this.selected,
    required this.icon,
    required this.selectedIcon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onTap,
      icon: Icon(selected ? selectedIcon : icon),
      color: selected ? AppColors.primary : AppColors.textSecondary,
      style: IconButton.styleFrom(
        backgroundColor: selected
            ? AppColors.primary.withValues(alpha: 0.1)
            : Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        fixedSize: const Size(54, 44),
      ),
    );
  }
}

class _DashboardTabBody extends ConsumerWidget {
  final BudgetSnapshot currentSnapshot;

  const _DashboardTabBody({required this.currentSnapshot});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final snapshotsAsync = ref.watch(allBudgetSnapshotsProvider);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
      child: snapshotsAsync.when(
        loading: () => const Padding(
          padding: EdgeInsets.only(top: 32),
          child: Center(child: CircularProgressIndicator()),
        ),
        error: (error, _) => ErrorView(error: error),
        data: (snapshots) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PeriodStatisticsChart(snapshots: snapshots),
            const SizedBox(height: 28),
            ExpenseStatisticsChart(snapshot: currentSnapshot),
          ],
        ),
      ),
    );
  }
}

class _BudgetTabBody extends StatelessWidget {
  final BudgetSnapshot snapshot;
  final VoidCallback onAddTap;
  final ValueChanged<CategoryBudget> onCategoryTap;
  final ValueChanged<CategoryBudget> onCategoryEdit;
  final ValueChanged<CategoryBudget> onCategoryIncrease;
  final ValueChanged<CategoryBudget> onCategoryDecrease;
  final ValueChanged<CategoryBudget> onCategorySetAmount;
  final ValueChanged<CategoryBudget> onCategoryDelete;
  final ValueChanged<CategoryBudget> onCategoryDeleteBlocked;

  const _BudgetTabBody({
    required this.snapshot,
    required this.onAddTap,
    required this.onCategoryTap,
    required this.onCategoryEdit,
    required this.onCategoryIncrease,
    required this.onCategoryDecrease,
    required this.onCategorySetAmount,
    required this.onCategoryDelete,
    required this.onCategoryDeleteBlocked,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      context.tr('budget_categories'),
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    _BudgetModeChip(
                      allocationsFollowIncome:
                          snapshot.period.allocationsFollowIncome,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              FilledButton.icon(
                onPressed: onAddTap,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                ),
                icon: const Icon(Icons.add_rounded, size: 18),
                label: Text(context.tr('add')),
              ),
            ],
          ),
          const SizedBox(height: 12),
          BudgetCategoryGrid(
            categories: snapshot.categories,
            transactions: snapshot.transactions,
            onCategoryTap: onCategoryTap,
            onCategoryEdit: onCategoryEdit,
            onCategoryIncrease: onCategoryIncrease,
            onCategoryDecrease: onCategoryDecrease,
            onCategorySetAmount: onCategorySetAmount,
            onCategoryDelete: onCategoryDelete,
            onCategoryDeleteBlocked: onCategoryDeleteBlocked,
            canDeleteCategory: (category) =>
                !snapshot.transactions.any(
                  (transaction) => transaction.categoryId == category.id,
                ) &&
                !snapshot.categoryAdjustments.any(
                  (adjustment) =>
                      adjustment.categoryId == category.id ||
                      adjustment.relatedCategoryId == category.id,
                ),
          ),
        ],
      ),
    );
  }
}

class _BudgetModeChip extends StatelessWidget {
  final bool allocationsFollowIncome;

  const _BudgetModeChip({required this.allocationsFollowIncome});

  @override
  Widget build(BuildContext context) {
    final color = allocationsFollowIncome
        ? AppColors.primary
        : AppColors.textSecondary;
    final icon = allocationsFollowIncome
        ? Icons.sync_alt_rounded
        : Icons.lock_outline_rounded;
    final label = allocationsFollowIncome
        ? context.tr('follows_income_2')
        : context.tr('fixed_amount');

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.09),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: 0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
