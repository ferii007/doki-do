import 'package:flutter/material.dart';

import '../../../../../app/theme/app_colors.dart';
import '../../../../../core/formatters/date_formatter.dart';
import '../../../../../core/localization/app_localizations.dart';
import '../../../domain/entities/budget_period.dart';

class PeriodSelectorSheet extends StatelessWidget {
  final List<BudgetPeriod> periods;
  final String selectedPeriodId;
  final ValueChanged<String> onSelect;
  final ValueChanged<BudgetPeriod> onDeletePeriod;
  final VoidCallback onAddPeriod;
  final bool isAdding;

  const PeriodSelectorSheet({
    super.key,
    required this.periods,
    required this.selectedPeriodId,
    required this.onSelect,
    required this.onDeletePeriod,
    required this.onAddPeriod,
    required this.isAdding,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.34),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              context.tr('choose_financial_period'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 10),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: periods.length,
                separatorBuilder: (_, _) => Divider(
                  color: Colors.white.withValues(alpha: 0.08),
                  height: 1,
                ),
                itemBuilder: (context, index) {
                  final period = periods[index];
                  final selected = period.id == selectedPeriodId;

                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      DateFormatter.periodFull(
                        period.startDate,
                        period.endDate,
                      ),
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: selected
                            ? FontWeight.w800
                            : FontWeight.w600,
                      ),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (selected)
                          Icon(Icons.check_circle, color: AppColors.secondary),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: () => onDeletePeriod(period),
                          icon: Icon(
                            Icons.delete_outline,
                            color: AppColors.danger,
                          ),
                        ),
                      ],
                    ),
                    onTap: () => onSelect(period.id),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: isAdding ? null : onAddPeriod,
                icon: const Icon(Icons.add),
                label: Text(
                  context.tr(isAdding ? 'adding' : 'add_financial_period'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
