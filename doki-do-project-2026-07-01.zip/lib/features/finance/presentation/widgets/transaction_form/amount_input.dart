import 'package:flutter/material.dart';

import '../../../../../core/formatters/currency_input_formatter.dart';
import '../../../../../core/formatters/rupiah_formatter.dart';
import '../../../../../core/localization/app_localizations.dart';

class AmountInput extends StatelessWidget {
  final TextEditingController controller;

  const AmountInput({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      inputFormatters: [CurrencyInputFormatter()],
      decoration: InputDecoration(
        labelText: context.tr('amount'),
        prefixText: CurrencyFormatterPreference.current.symbol,
        border: OutlineInputBorder(),
      ),
    );
  }
}
