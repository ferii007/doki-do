Map<String, dynamic> createEmptyFinanceData() {
  return {
    'status': 'success',
    'current_period_id': null,
    'periods': <Map<String, dynamic>>[],
  };
}
