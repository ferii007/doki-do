enum TransactionType { income, expense }
