class BudgetAllocationDraft {
  final String name;
  final int percentage;
  final int amount;

  const BudgetAllocationDraft({
    required this.name,
    required this.percentage,
    required this.amount,
  });
}
