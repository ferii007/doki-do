import 'package:flutter/material.dart';

class AppThemePalette {
  final String id;
  final String name;
  final String description;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color background;
  final Color surface;
  final Color mintSurface;
  final Color creamSurface;
  final Color textPrimary;
  final Color textSecondary;
  final Color border;
  final Color overlay;
  final Color sheet;
  final Color danger;
  final Color warning;

  const AppThemePalette({
    required this.id,
    required this.name,
    required this.description,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.background,
    required this.surface,
    required this.mintSurface,
    required this.creamSurface,
    required this.textPrimary,
    required this.textSecondary,
    required this.border,
    required this.overlay,
    required this.sheet,
    required this.danger,
    required this.warning,
  });

  LinearGradient get heroGradient {
    return LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [primary, Color.lerp(primary, overlay, 0.18)!],
    );
  }

  LinearGradient get warmGradient {
    return LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [surface, Color.lerp(surface, mintSurface, 0.52)!],
    );
  }
}

class AppThemePalettes {
  static const tealBalance = AppThemePalette(
    id: 'teal_balance',
    name: 'Teal Balance',
    description: 'fresh_modern_and_closest_to_dokido_s_identity',
    primary: Color(0xFF007979),
    secondary: Color(0xFF24B1B1),
    accent: Color(0xFFFFE0C5),
    background: Color(0xFFFFF0E4),
    surface: Color(0xFFFFFBF7),
    mintSurface: Color(0xFFE4F7F3),
    creamSurface: Color(0xFFFFF2E4),
    textPrimary: Color(0xFF173D3D),
    textSecondary: Color(0xFF64817C),
    border: Color(0xFFD6E6DE),
    overlay: Color(0xFF143836),
    sheet: Color(0xFF0D5F5F),
    danger: Color(0xFFD85B5B),
    warning: Color(0xFFE7A83D),
  );

  static const freshMint = AppThemePalette(
    id: 'fresh_mint',
    name: 'Fresh Mint',
    description: 'calm_fresh_green_and_comfortable_for_daily_use',
    primary: Color(0xFF659287),
    secondary: Color(0xFF88BDA4),
    accent: Color(0xFFB1D3B9),
    background: Color(0xFFE6F2DD),
    surface: Color(0xFFFBFFF8),
    mintSurface: Color(0xFFEAF6ED),
    creamSurface: Color(0xFFF4F8E9),
    textPrimary: Color(0xFF27433B),
    textSecondary: Color(0xFF637D70),
    border: Color(0xFFD8E6D8),
    overlay: Color(0xFF1D3832),
    sheet: Color(0xFF4D7B70),
    danger: Color(0xFFD85B5B),
    warning: Color(0xFFE0A642),
  );

  static const roseLedger = AppThemePalette(
    id: 'rose_ledger',
    name: 'Rose Ledger',
    description: 'warm_personal_with_a_strong_accent',
    primary: Color(0xFF850E35),
    secondary: Color(0xFFEE6983),
    accent: Color(0xFFFFC4C4),
    background: Color(0xFFFCF5EE),
    surface: Color(0xFFFFFBF8),
    mintSurface: Color(0xFFFFE4E8),
    creamSurface: Color(0xFFFFF0E5),
    textPrimary: Color(0xFF3B1220),
    textSecondary: Color(0xFF8B6671),
    border: Color(0xFFF0D6D6),
    overlay: Color(0xFF3B0A18),
    sheet: Color(0xFF6D0D2E),
    danger: Color(0xFFB4233E),
    warning: Color(0xFFE69B45),
  );

  static const sageBudget = AppThemePalette(
    id: 'sage_budget',
    name: 'Sage Budget',
    description: 'natural_soft_and_stable',
    primary: Color(0xFF89986D),
    secondary: Color(0xFF9CAB84),
    accent: Color(0xFFC5D89D),
    background: Color(0xFFF6F0D7),
    surface: Color(0xFFFFFCEF),
    mintSurface: Color(0xFFEAF1D6),
    creamSurface: Color(0xFFF9F1D4),
    textPrimary: Color(0xFF3C442F),
    textSecondary: Color(0xFF777D65),
    border: Color(0xFFE3DEC4),
    overlay: Color(0xFF333A28),
    sheet: Color(0xFF687650),
    danger: Color(0xFFD85B5B),
    warning: Color(0xFFD69A3A),
  );

  static const softLinen = AppThemePalette(
    id: 'soft_linen',
    name: 'Soft Linen',
    description: 'minimal_clean_and_calm_for_tidy_tracking',
    primary: Color(0xFFC9B59C),
    secondary: Color(0xFFD9CFC7),
    accent: Color(0xFFEFE9E3),
    background: Color(0xFFF9F8F6),
    surface: Color(0xFFFFFFFF),
    mintSurface: Color(0xFFF4EFE9),
    creamSurface: Color(0xFFFAF3EA),
    textPrimary: Color(0xFF40382F),
    textSecondary: Color(0xFF83786E),
    border: Color(0xFFE5DDD5),
    overlay: Color(0xFF3A3028),
    sheet: Color(0xFF8E7A64),
    danger: Color(0xFFD85B5B),
    warning: Color(0xFFD99B48),
  );

  static const warmSignal = AppThemePalette(
    id: 'warm_signal',
    name: 'Warm Signal',
    description: 'bright_clean_with_a_bold_accent',
    primary: Color(0xFFF62440),
    secondary: Color(0xFFFFE5BF),
    accent: Color(0xFFFFF2DB),
    background: Color(0xFFFFFAF3),
    surface: Color(0xFFFFFFFF),
    mintSurface: Color(0xFFFFEEE5),
    creamSurface: Color(0xFFFFF3D6),
    textPrimary: Color(0xFF3F2023),
    textSecondary: Color(0xFF8A6A63),
    border: Color(0xFFF3DEC1),
    overlay: Color(0xFF3C171D),
    sheet: Color(0xFFC51E33),
    danger: Color(0xFFF62440),
    warning: Color(0xFFE59A25),
  );

  static const values = [
    tealBalance,
    freshMint,
    roseLedger,
    sageBudget,
    softLinen,
    warmSignal,
  ];

  static AppThemePalette byId(String id) {
    return values.firstWhere(
      (palette) => palette.id == id,
      orElse: () => tealBalance,
    );
  }
}
