import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/formatters/date_formatter.dart';
import '../core/formatters/rupiah_formatter.dart';
import '../core/localization/app_localizations.dart';
import '../features/finance/presentation/screens/dashboard_screen.dart';
import '../features/settings/domain/entities/app_language.dart';
import '../features/settings/presentation/providers/app_settings_provider.dart';
import '../features/setup/presentation/screens/setup_screen.dart';
import 'router.dart';
import 'theme/app_colors.dart';
import 'theme/app_theme.dart';

class DokiDoApp extends ConsumerWidget {
  const DokiDoApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingsAsync = ref.watch(appSettingsProvider);
    final settings = settingsAsync.asData?.value;
    final language = settings?.language ?? AppLanguage.id;
    if (settings != null) {
      AppColors.applyPalette(settings.themePalette);
      CurrencyFormatterPreference.current = settings.currency;
      DateFormatterPreference.current = settings.language;
    }

    return MaterialApp(
      title: 'DokiDo Finance',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      locale: Locale(language.code),
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      routes: AppRouter.routes,
      builder: (context, child) => AppLocalizationsScope(
        localizations: AppLocalizations(language),
        child: child ?? const SizedBox.shrink(),
      ),
      home: AppLocalizationsScope(
        localizations: AppLocalizations(language),
        child: settingsAsync.when(
          loading: () => const _AppBootScreen(),
          error: (error, _) => _AppBootError(error: error),
          data: (settings) {
            AppColors.applyPalette(settings.themePalette);
            CurrencyFormatterPreference.current = settings.currency;
            DateFormatterPreference.current = settings.language;
            return settings.hasCompletedSetup
                ? const DashboardScreen()
                : SetupScreen(initialSettings: settings);
          },
        ),
      ),
    );
  }
}

class _AppBootScreen extends StatelessWidget {
  const _AppBootScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

class _AppBootError extends StatelessWidget {
  final Object error;

  const _AppBootError({required this.error});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            context.trf('failed_to_load_settings_error', {'error': error}),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
