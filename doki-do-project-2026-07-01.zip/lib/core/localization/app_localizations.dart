import 'package:flutter/widgets.dart';

import '../../features/settings/domain/entities/app_language.dart';

class AppLocalizations {
  final AppLanguage language;

  const AppLocalizations(this.language);

  static const supportedLocales = [Locale('id'), Locale('en')];

  static AppLocalizations of(BuildContext context) {
    final scope = context
        .dependOnInheritedWidgetOfExactType<AppLocalizationsScope>();
    return scope?.localizations ?? const AppLocalizations(AppLanguage.id);
  }

  String tr(String key) {
    if (language == AppLanguage.id) return _id[key] ?? key;
    return _en[key] ?? key;
  }

  String trf(String key, Map<String, Object> values) {
    var translated = tr(key);
    for (final entry in values.entries) {
      translated = translated.replaceAll('{${entry.key}}', '${entry.value}');
    }
    return translated;
  }

  String periodCount(int count) {
    if (language == AppLanguage.id) return '$count periode tercatat';
    return '$count recorded ${count == 1 ? 'period' : 'periods'}';
  }

  String expenseRecordCount(int count) {
    if (language == AppLanguage.id) return '$count catatan uang keluar';
    return '$count expense ${count == 1 ? 'record' : 'records'}';
  }

  String budgetDeleteMessage(String categoryName) {
    if (language == AppLanguage.id) {
      return 'Kategori "$categoryName" akan dihapus dari periode ini. Aksi ini tidak bisa dibatalkan.';
    }
    return 'Category "$categoryName" will be removed from this period. This action cannot be undone.';
  }

  String periodDeleteMessage(String periodLabel) {
    if (language == AppLanguage.id) {
      return 'Periode $periodLabel akan dihapus. Aksi ini tidak bisa dibatalkan.';
    }
    return 'Period $periodLabel will be deleted. This action cannot be undone.';
  }

  String categoryDeleteMessage(String name) {
    if (language == AppLanguage.id) {
      return 'Rencana "$name" akan dihapus dari form periode ini.';
    }
    return 'Plan "$name" will be removed from this period form.';
  }
}

class AppLocalizationsScope extends InheritedWidget {
  final AppLocalizations localizations;

  const AppLocalizationsScope({
    super.key,
    required this.localizations,
    required super.child,
  });

  @override
  bool updateShouldNotify(AppLocalizationsScope oldWidget) {
    return oldWidget.localizations.language != localizations.language;
  }
}

extension AppLocalizationsX on BuildContext {
  AppLocalizations get l10n => AppLocalizations.of(this);

  String tr(String key) => l10n.tr(key);

  String trf(String key, Map<String, Object> values) => l10n.trf(key, values);
}

const _id = <String, String>{
  'failed_to_load_settings_error': 'Settings gagal dibaca: {error}',
  'delete': 'Hapus',
  'cancel': 'Batal',
  'edit': 'Edit',
  'add': 'Tambah',
  'save': 'Simpan',
  'saving': 'Menyimpan...',
  'adding': 'Menambahkan...',
  'save_changes': 'Simpan Perubahan',
  'next': 'Lanjut',
  'start': 'Mulai',
  'create_period': 'Buat Periode',
  'create_financial_period': 'Buat Periode Keuangan',
  'add_financial_period': 'Tambah Periode Keuangan',
  'no_financial_period_yet': 'Belum ada periode keuangan',
  'create_your_first_period_so_income_expenses_and_budget_categories_can_be':
      'Buat periode pertama supaya uang masuk, uang keluar, dan kategori anggaran bisa mulai dicatat.',
  'budget_cannot_be_created_yet': 'Anggaran belum bisa dibuat',
  'add_a_financial_period_first_then_organize_budget_categories_for_that_pe':
      'Tambahkan periode keuangan dulu, lalu susun kategori anggaran untuk periode tersebut.',
  'create_a_financial_period_first': 'Buat periode keuangan dulu.',
  'create_a_financial_period_first_2': 'Buat periode keuangan dulu',
  'this_budget_category_cannot_be_deleted_because_it_already_has_expense_re':
      'Kategori anggaran ini belum bisa dihapus karena sudah punya catatan uang keluar.',
  'this_budget_category_cannot_be_deleted_because_it_already_has_history':
      'Kategori anggaran ini belum bisa dihapus karena sudah punya riwayat.',
  'budget_category_updated_successfully':
      'Kategori anggaran berhasil diperbarui.',
  'delete_budget_category': 'Hapus kategori anggaran?',
  'budget_category_deleted_successfully': 'Kategori anggaran berhasil dihapus.',
  'delete_financial_period': 'Hapus periode keuangan?',
  'financial_period_deleted_successfully': 'Periode keuangan berhasil dihapus.',
  'financial_period_period_added_successfully':
      'Periode keuangan {period} berhasil ditambahkan.',
  'this_period_cannot_be_deleted_because_it_already_has_income_or_expense_r':
      'Periode ini belum bisa dihapus karena sudah punya catatan uang masuk atau uang keluar.',
  'budget_categories': 'Kategori Anggaran',
  'amount': 'Jumlah Uang',
  'date': 'Tanggal',
  'financial_period': 'Periode Keuangan',
  'budget_category': 'Kategori anggaran',
  'remaining_money_this_period': 'Sisa Uang Periode Ini',
  'record_income': 'Catat Uang Masuk',
  'record_expense': 'Catat Uang Keluar',
  'add_budget_category': 'Tambah Kategori Anggaran',
  'where_did_this_money_come_from': 'Dari mana uang ini?',
  'what_was_it_used_for': 'Dipakai untuk apa?',
  'save_income': 'Simpan Uang Masuk',
  'save_expense': 'Simpan Uang Keluar',
  'save_budget_category': 'Simpan Kategori Anggaran',
  'choose_a_period_for_this_income_first':
      'Pilih periode untuk uang masuk ini dulu.',
  'choose_a_period_for_this_expense_first':
      'Pilih periode untuk uang keluar ini dulu.',
  'choose_the_budget_category_first': 'Pilih anggaran yang dipakai dulu.',
  'enter_the_income_amount_first': 'Isi jumlah uang masuk dulu.',
  'enter_the_expense_amount_first': 'Isi jumlah uang keluar dulu.',
  'enter_the_amount_first': 'Isi jumlah uangnya dulu.',
  'write_the_income_source_first': 'Tulis sumber uang masuknya dulu.',
  'write_what_the_money_was_used_for_first':
      'Tulis uangnya dipakai untuk apa dulu.',
  'fill_in_the_note_first': 'Isi catatannya dulu.',
  'income_recorded_successfully': 'Uang masuk berhasil dicatat.',
  'expense_recorded_successfully': 'Uang keluar berhasil dicatat.',
  'income_needs_to_be_placed_in_a_period_so_records_stay_organized':
      'Uang masuk perlu ditempatkan ke periode tertentu supaya catatannya rapi.',
  'expenses_need_to_be_placed_in_a_period_and_budget_category':
      'Uang keluar perlu ditempatkan ke periode dan kategori anggaran tertentu.',
  'create_a_financial_period_before_adding_a_budget_category':
      'Buat periode keuangan dulu sebelum menambah kategori anggaran.',
  'budget_category_name': 'Nama Kategori Anggaran',
  'choose_a_period_for_this_budget_category_first':
      'Pilih periode untuk kategori anggaran ini dulu.',
  'enter_the_budget_category_name_first': 'Isi nama kategori anggaran dulu.',
  'enter_the_budget_amount_first': 'Isi jumlah anggaran dulu.',
  'the_amount_exceeds_the_remaining_allocatable_balance_which_is_amount':
      'Jumlahnya melebihi sisa yang bisa dibagi, yaitu {amount}.',
  'budget_category_added_successfully':
      'Kategori anggaran berhasil ditambahkan.',
  'unallocated_balance': 'Sisa yang belum dibagi',
  'income_details': 'Rincian Uang Masuk',
  'expense_details': 'Rincian Uang Keluar',
  'budget_details': 'Rincian Anggaran',
  'create_a_financial_period_first_to_view_income':
      'Buat periode keuangan dulu untuk melihat uang masuk.',
  'create_a_financial_period_first_to_view_expenses':
      'Buat periode keuangan dulu untuk melihat uang keluar.',
  'create_a_financial_period_first_to_view_the_budget':
      'Buat periode keuangan dulu untuk melihat anggaran.',
  'this_budget_was_not_found': 'Anggaran ini tidak ditemukan.',
  'total_income': 'Total Uang Masuk',
  'total_expense': 'Total Uang Keluar',
  'income_history': 'Riwayat Uang Masuk',
  'expense_history': 'Riwayat Uang Keluar',
  'delete_expense': 'Hapus uang keluar?',
  'title_will_be_removed_from_income_history_this_action_cannot_be_undone':
      '"{title}" akan dihapus dari riwayat uang masuk. Aksi ini tidak bisa dibatalkan.',
  'title_will_be_removed_from_expense_history_this_action_cannot_be_undone':
      '"{title}" akan dihapus dari riwayat uang keluar. Aksi ini tidak bisa dibatalkan.',
  'no_expenses_in_this_category_yet': 'Belum ada uang keluar di kategori ini.',
  'no_expenses_recorded_in_this_period_yet':
      'Belum ada uang keluar di periode ini.',
  'budget_change_history': 'Riwayat Perubahan Anggaran',
  'no_budget_changes_yet': 'Belum ada perubahan anggaran.',
  'budget_increased': 'Anggaran Ditambah',
  'budget_decreased': 'Anggaran Dikurangi',
  'budget_set': 'Anggaran Diset',
  'no_income_recorded_in_this_period_yet':
      'Belum ada uang masuk di periode ini.',
  'delete_income': 'Hapus uang masuk?',
  'this_income_record_will_be_deleted_this_action_cannot_be_undone':
      'Uang masuk ini akan dihapus. Aksi ini tidak bisa dibatalkan.',
  'income_updated_successfully': 'Uang masuk berhasil diperbarui.',
  'income_deleted_successfully': 'Uang masuk berhasil dihapus.',
  'edit_expense': 'Edit Uang Keluar',
  'edit_income': 'Edit Uang Masuk',
  'financial_profile': 'Profil Keuangan',
  'dokido_user': 'Pengguna DokiDo',
  'recorded_periods': 'Periode Tercatat',
  'active_categories': 'Kategori Aktif',
  'income': 'Uang Masuk',
  'expense': 'Uang Keluar',
  'this_period_is_still_on_track': 'Uang periode ini masih aman',
  'this_period_needs_attention': 'Uang periode ini perlu dicek',
  'account_profile': 'Profil Akun',
  'local': 'Lokal',
  'display_name': 'Nama yang Ditampilkan',
  'tracking_pattern': 'Pola Pencatatan',
  'login_and_security': 'Masuk Akun & Keamanan',
  'not_active': 'Belum aktif',
  'app_appearance': 'Tampilan Aplikasi',
  'app_preferences': 'Preferensi Aplikasi',
  'theme': 'Tema',
  'choose_color_theme': 'Pilih Tema Warna',
  'choose_language': 'Pilih Bahasa',
  'choose_currency': 'Pilih Mata Uang',
  'settings_updated_successfully': 'Pengaturan berhasil diperbarui.',
  'powered_by_feri': 'Powered by Feri',
  'primary': 'Utama',
  'palette': 'Palette',
  'currency': 'Mata Uang',
  'language_and_format': 'Bahasa dan Format',
  'language': 'Bahasa',
  'currency_symbol': 'Simbol Mata Uang',
  'daily_tracking': 'Pencatatan Harian',
  'new_record_date': 'Tanggal Catatan Baru',
  'today': 'Hari ini',
  'quick_add_default': 'Pilihan Tambah Cepat',
  'note_required': 'Catatan Harus Diisi',
  'off': 'Nonaktif',
  'period_and_budget': 'Periode dan Anggaran',
  'period_start_date': 'Tanggal Mulai Periode',
  'the_22nd_of_every_month': 'Tanggal 22 setiap bulan',
  'default_template': 'Template Awal',
  'new_budget_calculation': 'Cara Hitung Anggaran Baru',
  'follows_income': 'Ikut uang masuk',
  'follows_income_2': 'Ikut Uang Masuk',
  'from_income': 'dari uang masuk',
  'reminders': 'Pengingat',
  'daily_tracking_reminder': 'Ingatkan Catat Harian',
  'reminder_time': 'Jam Pengingat',
  'end_period_reminder': 'Pengingat Akhir Periode',
  'data': 'Data',
  'data_mode': 'Mode Data',
  'local_device_storage': 'Storage lokal perangkat',
  'download_data': 'Unduh Data',
  'online_sync': 'Sinkronisasi Online',
  'not_connected': 'Belum tersambung',
  'financial_statistics': 'Statistik Keuangan',
  'no_recorded_periods_yet': 'Belum ada periode tercatat',
  'no_financial_data_yet': 'Belum ada data keuangan',
  'create_a_financial_period_first_the_summary_will_appear_here':
      'Buat periode keuangan dulu, nanti ringkasannya muncul di sini.',
  'choose_chart_type': 'Pilih Bentuk Grafik',
  'line_chart': 'Grafik Garis',
  'column_chart': 'Grafik Kolom',
  'expense_statistics': 'Statistik Uang Keluar',
  'no_expenses_yet': 'Belum ada uang keluar',
  'expense_records_in_this_period_will_appear_here':
      'Catatan uang keluar di periode ini akan muncul di sini.',
  'choose_financial_period': 'Pilih Periode Keuangan',
  'budget_limit': 'Batas Anggaran',
  'remaining_money': 'Sisa Uang',
  'budget_category_options': 'Pilihan kategori anggaran',
  'expense_options': 'Pilihan uang keluar',
  'add_budget_amount': 'Tambah Anggaran',
  'reduce_budget_amount': 'Kurangi Anggaran',
  'set_budget_amount': 'Set Anggaran',
  'reason': 'Alasan',
  'write_the_reason_first': 'Tulis alasannya dulu.',
  'take_from_another_category': 'Ambil dari kategori lain',
  'move_to_another_category': 'Pindahkan ke kategori lain',
  'balance_with_another_category': 'Imbangi dengan kategori lain',
  'do_not_use_another_category': 'Tidak memakai kategori lain',
  'only_this_category_amount_will_change':
      'Nominal hanya berubah di kategori ini',
  'change_impact': 'Dampak Perubahan',
  'budget_adjusted_successfully': 'Anggaran berhasil disesuaikan.',
  'add_data': 'Tambah Data',
  'choose_the_type_of_record_you_want_to_create':
      'Pilih jenis catatan yang mau dibuat.',
  'new_budget_category': 'Kategori Anggaran Baru',
  'new_period': 'Periode Baru',
  'edit_budget_category': 'Edit Kategori Anggaran',
  'budget_amount': 'Jumlah anggaran',
  'delete_budget_plan': 'Hapus rencana anggaran?',
  'budget_category_names_cannot_be_duplicated':
      'Nama kategori anggaran tidak boleh sama.',
  'choose_the_start_and_end_dates_first':
      'Pilih tanggal mulai dan selesai periode dulu.',
  'the_end_date_must_be_after_the_start_date':
      'Tanggal selesai periode harus setelah tanggal mulai.',
  'enter_the_opening_balance_first': 'Isi saldo awal periode dulu.',
  'write_the_opening_balance_source_first': 'Tulis sumber saldo awalnya dulu.',
  'add_at_least_one_initial_budget_plan':
      'Tambahkan minimal satu rencana anggaran awal.',
  'all_custom_percentages_must_be_greater_than_0':
      'Semua persentase buatanmu harus lebih dari 0.',
  'total_percentage_must_be_exactly_100': 'Total persentase harus tepat 100%.',
  'all_custom_amounts_must_be_greater_than_0':
      'Semua nominal buatanmu harus lebih dari 0.',
  'total_amount_cannot_exceed_the_opening_balance':
      'Total nominal tidak boleh melebihi saldo awal.',
  'total_amount_exceeds_the_opening_balance_of_amount':
      'Total nominal melebihi saldo awal {amount}.',
  'the_selected_date_overlaps_with_an_existing_period':
      'Tanggal yang dipilih bertabrakan dengan periode yang sudah ada.',
  'how_to_split_the_balance': 'Cara Membagi Saldo',
  'budget': 'Anggaran',
  'add_period': 'Tambah Periode',
  'save_period': 'Simpan Periode',
  'opening_balance': 'Saldo Awal',
  'opening_balance_source': 'Sumber Saldo Awal',
  'transfer_remaining_money_from_the_previous_period':
      'Transfer sisa periode sebelumnya?',
  'initial_budget_plan': 'Rencana Anggaran Awal',
  'allocation_preview': 'Preview Alokasi',
  'allocation_formula': 'Rumus Alokasi',
  'popular_template': 'Template Populer',
  'customize': 'Atur Sendiri',
  'percentage': 'Persentase',
  'amount_2': 'Nominal',
  'rupiah': 'Rupiah',
  'adjust_with_every_income': 'Ikut Setiap Uang Masuk',
  'fixed_amount': 'Jumlah Tetap',
  'amount_changes_when_income_changes':
      'Jumlah ikut berubah saat uang masuk berubah',
  'amount_is_not_recalculated': 'Jumlah tidak dihitung ulang',
  'end': 'Selesai',
  'choose_date': 'Pilih Tanggal',
  'choose_date_2': 'Pilih tanggal',
  'choose_start_and_end_date': 'Pilih tanggal mulai dan selesai',
  'start_date_value': 'Mulai {date}',
  'default_budget': 'Anggaran Default',
  'review': 'Review',
  'profile': 'Profil',
  'preferences': 'Preferensi',
  'period': 'Periode',
  'category': 'Kategori',
  'allocation': 'Alokasi',
  'display_name_2': 'Nama Tampilan',
  'quick_introduction': 'Kenalan Sebentar',
  'this_name_will_be_used_in_your_profile_and_app_summaries':
      'Nama Ini Akan Dipakai Di Profil Dan Ringkasan Aplikasi.',
  'write_your_name': 'Tulis Nama Kamu',
  'choose_app_style': 'Pilih Gaya Aplikasi',
  'you_can_change_this_later_from_settings':
      'Kamu Bisa Ubah Lagi Nanti Dari Settings.',
  'color_theme': 'Tema Warna',
  'create_your_first_period': 'Buat Periode Pertama',
  'all_money_records_will_go_into_the_period_you_choose':
      'Semua Catatan Uang Akan Masuk Ke Periode Yang Kamu Pilih.',
  'start_date': 'Tanggal Mulai',
  'end_date': 'Tanggal Selesai',
  'enter_opening_balance': 'Masukkan Saldo Awal',
  'this_becomes_the_first_income_record_for_that_period':
      'Ini Menjadi Uang Masuk Pertama Untuk Periode Tersebut.',
  'received_date': 'Tanggal Diterima',
  'set_up_budget_categories': 'Susun Kategori Anggaran',
  'use_the_categories_you_track_most_often':
      'Gunakan Kategori Yang Paling Sering Kamu Pantau.',
  'initial_categories': 'Kategori Awal',
  'choose_how_to_split_the_balance': 'Pilih Cara Membagi Saldo',
  'dokido_will_calculate_category_amounts_from_your_opening_balance':
      'DokiDo Akan Menghitung Nominal Kategori Dari Saldo Awalmu.',
  'custom_percentage': 'Persentase Kustom',
  'custom_amount': 'Nominal Kustom',
  'review_before_starting': 'Cek Dulu Sebelum Mulai',
  'if_everything_looks_right_dokido_will_prepare_your_dashboard':
      'Kalau Sudah Benar, DokiDo Akan Menyiapkan Dashboard Kamu.',
  'name': 'Nama',
  'balance_source': 'Sumber Saldo',
  'unallocated_balance_2': 'Sisa Belum Dibagi',
  'category_name': 'Nama Kategori',
  'enter_percentages_or_amounts_for_each_category':
      'Isi Persentase Atau Nominal Sesuai Kategori.',
  'enter_your_display_name_first': 'Isi Nama Tampilan Dulu.',
  'choose_the_period_start_and_end_dates_first':
      'Pilih Tanggal Mulai Dan Selesai Periode.',
  'the_end_date_must_be_after_the_start_date_2':
      'Tanggal Selesai Harus Setelah Tanggal Mulai.',
  'enter_the_opening_balance_first_2': 'Isi Saldo Awal Periode Dulu.',
  'write_the_opening_balance_source_first_2':
      'Tulis Sumber Saldo Awalnya Dulu.',
  'add_at_least_one_budget_category':
      'Tambahkan Minimal Satu Kategori Anggaran.',
  'budget_category_names_cannot_be_duplicated_2':
      'Nama Kategori Anggaran Tidak Boleh Sama.',
  'setup_complete_dokido_is_ready_to_use':
      'Setup selesai. DokiDo siap dipakai.',
  'there_must_be_at_least_one_budget_category':
      'Minimal Harus Ada Satu Kategori Anggaran.',
  'all_percentages_must_be_greater_than_0':
      'Semua Persentase Harus Lebih Dari 0%.',
  'total_percentage_must_be_exactly_100_2':
      'Total Persentase Harus Tepat 100%.',
  'all_amounts_must_be_greater_than_0': 'Semua Nominal Harus Lebih Dari 0.',
  'total_amount_cannot_exceed_the_opening_balance_2':
      'Total Nominal Tidak Boleh Melebihi Saldo Awal.',
  'example_feri': 'Contoh: Feri',
  'example_main_salary_freelance_bonus': 'Contoh: Gaji Utama, Freelance, Bonus',
  'opening_balance_source_2': 'Sumber saldo awal',
  'example_savings_balance_cash_or_this_month_s_money':
      'Contoh: Saldo tabungan, kas, atau uang bulan ini',
  'example_50': 'Contoh: 50',
  'example_1_000_000': 'Contoh: 1,000,000',
  'choose_the_currency_and_visual_style_that_feels_comfortable':
      'Pilih mata uang dan gaya tampilan yang nyaman untukmu.',
  'fresh_modern_and_closest_to_dokido_s_identity':
      'Segar, modern, dan paling dekat dengan identitas DokiDo.',
  'calm_fresh_green_and_comfortable_for_daily_use':
      'Kalem, hijau segar, dan nyaman untuk dipakai harian.',
  'warm_personal_with_a_strong_accent':
      'Hangat, personal, dan punya aksen kuat.',
  'natural_soft_and_stable': 'Natural, lembut, dan terasa stabil.',
  'minimal_clean_and_calm_for_tidy_tracking':
      'Minimal, bersih, dan tenang untuk pencatatan rapi.',
  'bright_clean_with_a_bold_accent':
      'Cerah, bersih, dan punya aksen yang berani.',
};

const _en = <String, String>{
  'failed_to_load_settings_error': 'Failed to load settings: {error}',
  'delete': 'Delete',
  'cancel': 'Cancel',
  'edit': 'Edit',
  'add': 'Add',
  'save': 'Save',
  'saving': 'Saving...',
  'adding': 'Adding...',
  'save_changes': 'Save Changes',
  'next': 'Next',
  'start': 'Start',
  'create_period': 'Create Period',
  'create_financial_period': 'Create Financial Period',
  'add_financial_period': 'Add Financial Period',
  'no_financial_period_yet': 'No Financial Period Yet',
  'create_your_first_period_so_income_expenses_and_budget_categories_can_be':
      'Create your first period so income, expenses, and budget categories can be tracked.',
  'budget_cannot_be_created_yet': 'Budget Cannot Be Created Yet',
  'add_a_financial_period_first_then_organize_budget_categories_for_that_pe':
      'Add a financial period first, then organize budget categories for that period.',
  'create_a_financial_period_first': 'Create a financial period first.',
  'create_a_financial_period_first_2': 'Create a financial period first',
  'this_budget_category_cannot_be_deleted_because_it_already_has_expense_re':
      'This budget category cannot be deleted because it already has expense records.',
  'this_budget_category_cannot_be_deleted_because_it_already_has_history':
      'This budget category cannot be deleted because it already has history.',
  'budget_category_updated_successfully':
      'Budget category updated successfully.',
  'delete_budget_category': 'Delete budget category?',
  'budget_category_deleted_successfully':
      'Budget category deleted successfully.',
  'delete_financial_period': 'Delete financial period?',
  'financial_period_deleted_successfully':
      'Financial period deleted successfully.',
  'financial_period_period_added_successfully':
      'Financial period {period} added successfully.',
  'this_period_cannot_be_deleted_because_it_already_has_income_or_expense_r':
      'This period cannot be deleted because it already has income or expense records.',
  'budget_categories': 'Budget Categories',
  'amount': 'Amount',
  'date': 'Date',
  'financial_period': 'Financial Period',
  'budget_category': 'Budget category',
  'remaining_money_this_period': 'Remaining Money This Period',
  'record_income': 'Record Income',
  'record_expense': 'Record Expense',
  'add_budget_category': 'Add Budget Category',
  'where_did_this_money_come_from': 'Where did this money come from?',
  'what_was_it_used_for': 'What was it used for?',
  'save_income': 'Save Income',
  'save_expense': 'Save Expense',
  'save_budget_category': 'Save Budget Category',
  'choose_a_period_for_this_income_first':
      'Choose a period for this income first.',
  'choose_a_period_for_this_expense_first':
      'Choose a period for this expense first.',
  'choose_the_budget_category_first': 'Choose the budget category first.',
  'enter_the_income_amount_first': 'Enter the income amount first.',
  'enter_the_expense_amount_first': 'Enter the expense amount first.',
  'enter_the_amount_first': 'Enter the amount first.',
  'write_the_income_source_first': 'Write the income source first.',
  'write_what_the_money_was_used_for_first':
      'Write what the money was used for first.',
  'fill_in_the_note_first': 'Fill in the note first.',
  'income_recorded_successfully': 'Income recorded successfully.',
  'expense_recorded_successfully': 'Expense recorded successfully.',
  'income_needs_to_be_placed_in_a_period_so_records_stay_organized':
      'Income needs to be placed in a period so records stay organized.',
  'expenses_need_to_be_placed_in_a_period_and_budget_category':
      'Expenses need to be placed in a period and budget category.',
  'create_a_financial_period_before_adding_a_budget_category':
      'Create a financial period before adding a budget category.',
  'budget_category_name': 'Budget Category Name',
  'choose_a_period_for_this_budget_category_first':
      'Choose a period for this budget category first.',
  'enter_the_budget_category_name_first':
      'Enter the budget category name first.',
  'enter_the_budget_amount_first': 'Enter the budget amount first.',
  'the_amount_exceeds_the_remaining_allocatable_balance_which_is_amount':
      'The amount exceeds the remaining allocatable balance, which is {amount}.',
  'budget_category_added_successfully': 'Budget category added successfully.',
  'unallocated_balance': 'Unallocated balance',
  'income_details': 'Income Details',
  'expense_details': 'Expense Details',
  'budget_details': 'Budget Details',
  'create_a_financial_period_first_to_view_income':
      'Create a financial period first to view income.',
  'create_a_financial_period_first_to_view_expenses':
      'Create a financial period first to view expenses.',
  'create_a_financial_period_first_to_view_the_budget':
      'Create a financial period first to view the budget.',
  'this_budget_was_not_found': 'This budget was not found.',
  'total_income': 'Total Income',
  'total_expense': 'Total Expense',
  'income_history': 'Income History',
  'expense_history': 'Expense History',
  'delete_expense': 'Delete expense?',
  'title_will_be_removed_from_income_history_this_action_cannot_be_undone':
      '"{title}" will be removed from income history. This action cannot be undone.',
  'title_will_be_removed_from_expense_history_this_action_cannot_be_undone':
      '"{title}" will be removed from expense history. This action cannot be undone.',
  'no_expenses_in_this_category_yet': 'No expenses in this category yet.',
  'no_expenses_recorded_in_this_period_yet':
      'No expenses recorded in this period yet.',
  'budget_change_history': 'Budget Change History',
  'no_budget_changes_yet': 'No budget changes yet.',
  'budget_increased': 'Budget Increased',
  'budget_decreased': 'Budget Decreased',
  'budget_set': 'Budget Set',
  'no_income_recorded_in_this_period_yet':
      'No income recorded in this period yet.',
  'delete_income': 'Delete income?',
  'this_income_record_will_be_deleted_this_action_cannot_be_undone':
      'This income record will be deleted. This action cannot be undone.',
  'income_updated_successfully': 'Income updated successfully.',
  'income_deleted_successfully': 'Income deleted successfully.',
  'edit_expense': 'Edit Expense',
  'edit_income': 'Edit Income',
  'financial_profile': 'Financial Profile',
  'dokido_user': 'DokiDo User',
  'recorded_periods': 'Recorded Periods',
  'active_categories': 'Active Categories',
  'income': 'Income',
  'expense': 'Expense',
  'this_period_is_still_on_track': 'This period is still on track',
  'this_period_needs_attention': 'This period needs attention',
  'account_profile': 'Account Profile',
  'local': 'Local',
  'display_name': 'Display Name',
  'tracking_pattern': 'Tracking Pattern',
  'login_and_security': 'Login & Security',
  'not_active': 'Not active',
  'app_appearance': 'App Appearance',
  'app_preferences': 'App Preferences',
  'theme': 'Theme',
  'choose_color_theme': 'Choose Color Theme',
  'choose_language': 'Choose Language',
  'choose_currency': 'Choose Currency',
  'settings_updated_successfully': 'Settings updated successfully.',
  'powered_by_feri': 'Powered by Feri',
  'primary': 'Primary',
  'palette': 'Palette',
  'currency': 'Currency',
  'language_and_format': 'Language & Format',
  'language': 'Language',
  'currency_symbol': 'Currency Symbol',
  'daily_tracking': 'Daily Tracking',
  'new_record_date': 'New Record Date',
  'today': 'Today',
  'quick_add_default': 'Quick Add Default',
  'note_required': 'Note Required',
  'off': 'Off',
  'period_and_budget': 'Period & Budget',
  'period_start_date': 'Period Start Date',
  'the_22nd_of_every_month': 'The 22nd of every month',
  'default_template': 'Default Template',
  'new_budget_calculation': 'New Budget Calculation',
  'follows_income': 'Follows income',
  'follows_income_2': 'Follows Income',
  'from_income': 'from income',
  'reminders': 'Reminders',
  'daily_tracking_reminder': 'Daily Tracking Reminder',
  'reminder_time': 'Reminder Time',
  'end_period_reminder': 'End Period Reminder',
  'data': 'Data',
  'data_mode': 'Data Mode',
  'local_device_storage': 'Local device storage',
  'download_data': 'Download Data',
  'online_sync': 'Online Sync',
  'not_connected': 'Not connected',
  'financial_statistics': 'Financial Statistics',
  'no_recorded_periods_yet': 'No recorded periods yet',
  'no_financial_data_yet': 'No financial data yet',
  'create_a_financial_period_first_the_summary_will_appear_here':
      'Create a financial period first. The summary will appear here.',
  'choose_chart_type': 'Choose Chart Type',
  'line_chart': 'Line Chart',
  'column_chart': 'Column Chart',
  'expense_statistics': 'Expense Statistics',
  'no_expenses_yet': 'No expenses yet',
  'expense_records_in_this_period_will_appear_here':
      'Expense records in this period will appear here.',
  'choose_financial_period': 'Choose Financial Period',
  'budget_limit': 'Budget Limit',
  'remaining_money': 'Remaining Money',
  'budget_category_options': 'Budget category options',
  'expense_options': 'Expense options',
  'add_budget_amount': 'Add Budget Amount',
  'reduce_budget_amount': 'Reduce Budget Amount',
  'set_budget_amount': 'Set Budget Amount',
  'reason': 'Reason',
  'write_the_reason_first': 'Write the reason first.',
  'take_from_another_category': 'Take from another category',
  'move_to_another_category': 'Move to another category',
  'balance_with_another_category': 'Balance with another category',
  'do_not_use_another_category': 'Do not use another category',
  'only_this_category_amount_will_change':
      'Only this category amount will change',
  'change_impact': 'Change Impact',
  'budget_adjusted_successfully': 'Budget adjusted successfully.',
  'add_data': 'Add Data',
  'choose_the_type_of_record_you_want_to_create':
      'Choose the type of record you want to create.',
  'new_budget_category': 'New Budget Category',
  'new_period': 'New Period',
  'edit_budget_category': 'Edit Budget Category',
  'budget_amount': 'Budget Amount',
  'delete_budget_plan': 'Delete budget plan?',
  'budget_category_names_cannot_be_duplicated':
      'Budget category names cannot be duplicated.',
  'choose_the_start_and_end_dates_first':
      'Choose the start and end dates first.',
  'the_end_date_must_be_after_the_start_date':
      'The end date must be after the start date.',
  'enter_the_opening_balance_first': 'Enter the opening balance first.',
  'write_the_opening_balance_source_first':
      'Write the opening balance source first.',
  'add_at_least_one_initial_budget_plan':
      'Add at least one initial budget plan.',
  'all_custom_percentages_must_be_greater_than_0':
      'All custom percentages must be greater than 0.',
  'total_percentage_must_be_exactly_100':
      'Total percentage must be exactly 100%.',
  'all_custom_amounts_must_be_greater_than_0':
      'All custom amounts must be greater than 0.',
  'total_amount_cannot_exceed_the_opening_balance':
      'Total amount cannot exceed the opening balance.',
  'total_amount_exceeds_the_opening_balance_of_amount':
      'Total amount exceeds the opening balance of {amount}.',
  'the_selected_date_overlaps_with_an_existing_period':
      'The selected date overlaps with an existing period.',
  'how_to_split_the_balance': 'How to Split the Balance',
  'budget': 'Budget',
  'add_period': 'Add Period',
  'save_period': 'Save Period',
  'opening_balance': 'Opening Balance',
  'opening_balance_source': 'Opening Balance Source',
  'transfer_remaining_money_from_the_previous_period':
      'Transfer remaining money from the previous period?',
  'initial_budget_plan': 'Initial Budget Plan',
  'allocation_preview': 'Allocation Preview',
  'allocation_formula': 'Allocation Formula',
  'popular_template': 'Popular Template',
  'customize': 'Customize',
  'percentage': 'Percentage',
  'amount_2': 'Amount',
  'rupiah': 'Rupiah',
  'adjust_with_every_income': 'Adjust With Every Income',
  'fixed_amount': 'Fixed Amount',
  'amount_changes_when_income_changes': 'Amount changes when income changes',
  'amount_is_not_recalculated': 'Amount is not recalculated',
  'end': 'End',
  'choose_date': 'Choose Date',
  'choose_date_2': 'Choose Date',
  'choose_start_and_end_date': 'Choose start and end date',
  'start_date_value': 'Start {date}',
  'default_budget': 'Default Budget',
  'review': 'Review',
  'profile': 'Profile',
  'preferences': 'Preferences',
  'period': 'Period',
  'category': 'Category',
  'allocation': 'Allocation',
  'display_name_2': 'Display Name',
  'quick_introduction': 'Quick Introduction',
  'this_name_will_be_used_in_your_profile_and_app_summaries':
      'This name will be used in your profile and app summaries.',
  'write_your_name': 'Write Your Name',
  'choose_app_style': 'Choose App Style',
  'you_can_change_this_later_from_settings':
      'You can change this later from Settings.',
  'color_theme': 'Color Theme',
  'create_your_first_period': 'Create Your First Period',
  'all_money_records_will_go_into_the_period_you_choose':
      'All money records will go into the period you choose.',
  'start_date': 'Start Date',
  'end_date': 'End Date',
  'enter_opening_balance': 'Enter Opening Balance',
  'this_becomes_the_first_income_record_for_that_period':
      'This becomes the first income record for that period.',
  'received_date': 'Received Date',
  'set_up_budget_categories': 'Set Up Budget Categories',
  'use_the_categories_you_track_most_often':
      'Use the categories you track most often.',
  'initial_categories': 'Initial Categories',
  'choose_how_to_split_the_balance': 'Choose How to Split the Balance',
  'dokido_will_calculate_category_amounts_from_your_opening_balance':
      'DokiDo will calculate category amounts from your opening balance.',
  'custom_percentage': 'Custom Percentage',
  'custom_amount': 'Custom Amount',
  'review_before_starting': 'Review Before Starting',
  'if_everything_looks_right_dokido_will_prepare_your_dashboard':
      'If everything looks right, DokiDo will prepare your dashboard.',
  'name': 'Name',
  'balance_source': 'Balance Source',
  'unallocated_balance_2': 'Unallocated Balance',
  'category_name': 'Category Name',
  'enter_percentages_or_amounts_for_each_category':
      'Enter percentages or amounts for each category.',
  'enter_your_display_name_first': 'Enter your display name first.',
  'choose_the_period_start_and_end_dates_first':
      'Choose the period start and end dates first.',
  'the_end_date_must_be_after_the_start_date_2':
      'The end date must be after the start date.',
  'enter_the_opening_balance_first_2': 'Enter the opening balance first.',
  'write_the_opening_balance_source_first_2':
      'Write the opening balance source first.',
  'add_at_least_one_budget_category': 'Add at least one budget category.',
  'budget_category_names_cannot_be_duplicated_2':
      'Budget category names cannot be duplicated.',
  'setup_complete_dokido_is_ready_to_use':
      'Setup complete. DokiDo is ready to use.',
  'there_must_be_at_least_one_budget_category':
      'There must be at least one budget category.',
  'all_percentages_must_be_greater_than_0':
      'All percentages must be greater than 0%.',
  'total_percentage_must_be_exactly_100_2':
      'Total percentage must be exactly 100%.',
  'all_amounts_must_be_greater_than_0': 'All amounts must be greater than 0.',
  'total_amount_cannot_exceed_the_opening_balance_2':
      'Total amount cannot exceed the opening balance.',
  'example_feri': 'Example: Feri',
  'example_main_salary_freelance_bonus':
      'Example: Main Salary, Freelance, Bonus',
  'opening_balance_source_2': 'Opening balance source',
  'example_savings_balance_cash_or_this_month_s_money':
      'Example: savings balance, cash, or this month’s money',
  'example_50': 'Example: 50',
  'example_1_000_000': 'Example: 1,000,000',
  'choose_the_currency_and_visual_style_that_feels_comfortable':
      'Choose the currency and visual style that feels comfortable.',
  'fresh_modern_and_closest_to_dokido_s_identity':
      'Fresh, modern, and closest to DokiDo’s identity.',
  'calm_fresh_green_and_comfortable_for_daily_use':
      'Calm, fresh green, and comfortable for daily use.',
  'warm_personal_with_a_strong_accent': 'Warm, personal, with a strong accent.',
  'natural_soft_and_stable': 'Natural, soft, and stable.',
  'minimal_clean_and_calm_for_tidy_tracking':
      'Minimal, clean, and calm for tidy tracking.',
  'bright_clean_with_a_bold_accent': 'Bright, clean, with a bold accent.',
};
